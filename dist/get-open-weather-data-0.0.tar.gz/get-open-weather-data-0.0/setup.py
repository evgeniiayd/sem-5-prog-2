from setuptools import setup

setup(name='get-open-weather-data',
      version='0.0',
      description='https://github.com/evgeniiayd/sem-5-prog-2',
      packages=['get-open-weather-data'],
      author_email='evgeniiappletree@mail.com',
      zip_safe=False)
